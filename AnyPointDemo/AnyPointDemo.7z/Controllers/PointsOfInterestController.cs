﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using AnyPointDemo.Entities;
using AnyPointDemo.Models;
using AnyPointDemo.Services;
using Microsoft.Practices.Unity;
using AutoMapper;

namespace AnyPointDemo.Controllers
{
    /// <summary>
    /// Points of interest controller
    /// </summary>
    [RoutePrefix("api")]
    public class PointsOfInterestController : ApiController
    {
        private ICityInfoRepository _cityInfoRepository;

	    public PointsOfInterestController()
        {
            _cityInfoRepository = _cityInfoRepository = IocContainer.Instance.Resolve<ICityInfoRepository>();
		}

        [HttpGet]
		[Route("cities/{cityId}/pointsofinterest")]
        public IHttpActionResult GetPointsOfInterest(int cityId)
        {
            try
            {
                if (!_cityInfoRepository.CityExists(cityId))
                {
                    return NotFound();
                }

	            return Ok(Mapper.Map<IEnumerable<PointOfInterestDto>>(_cityInfoRepository.GetPointsOfInterestForCity(cityId)));
            }
            catch (Exception e)
            {
				//"A problem happened while handling your request"
				return InternalServerError();
            }
            
        }

        [HttpGet]
		[Route("cities/{cityId}/pointsofinterest/{id}", Name = "GetPointOfInterest")]
        public IHttpActionResult GetPointOfInterest(int cityId, int id)
        {
			if (!_cityInfoRepository.CityExists(cityId)) return NotFound();

	        var pointOfInterestFromDb = _cityInfoRepository.GetPointOfInterestForCity(cityId, id);
	        if (pointOfInterestFromDb == null) return NotFound();

	        return Ok(Mapper.Map<PointOfInterestDto>(pointOfInterestFromDb));
        }

        [HttpPost]
        [Route("cities/{cityId}/pointsofinterest")]
        public IHttpActionResult CreatePointOfInterest(int cityId,
			[FromBody] PointOfInterestForCreationDto pointOfInterest)
        {
			//var results = _validator.Validate(pointOfInterest);

	   //     if (!results.IsValid)
	   //     {
				//var sb = new StringBuilder();
		  //      foreach (var failure in results.Errors)
			 //       sb.Append("Property " + failure.PropertyName + " failed validation. Error was: " +
			 //                 failure.ErrorMessage + Environment.NewLine);
		  //      return BadRequest(sb.ToString());
	   //     }


	        if (pointOfInterest == null) return BadRequest();

            if (pointOfInterest.Description == pointOfInterest.Name)
                ModelState.AddModelError("Description", "Description should not be equal to name");

            if (!ModelState.IsValid) return BadRequest(ModelState);

            if (!_cityInfoRepository.CityExists(cityId)) return NotFound();

	        var pointToCreate = Mapper.Map<PointOfInterest>(pointOfInterest);
			_cityInfoRepository.AddPointOfInterestForCity(cityId, pointToCreate);

			//500, "An error occurred while handling your request"
			if (!_cityInfoRepository.Save()) return InternalServerError();

			var createdPointOfInterest = Mapper.Map<PointOfInterestDto>(pointToCreate);

	        return CreatedAtRoute("GetPointOfInterest",
		        new {cityId = cityId, id = createdPointOfInterest.Id}, createdPointOfInterest);
        }

        [HttpPut]
        [Route("cities/{cityId}/pointsofinterest/{id}")]
        public IHttpActionResult UpdatePointOfInterest(int cityId, int id, [FromBody] PointOfInterestForCreationDto pointOfInterest)
        {
            if (pointOfInterest == null) return BadRequest();

            if (pointOfInterest.Description == pointOfInterest.Name)
                ModelState.AddModelError("Description", "Description should not be equal to name");

            if (!ModelState.IsValid) return BadRequest(ModelState);

            if (!_cityInfoRepository.CityExists(cityId)) return NotFound();

	        var pointToUpdate = _cityInfoRepository.GetPointOfInterestForCity(cityId, id);
            if (pointToUpdate == null) return NotFound();

	        Mapper.Map(pointOfInterest, pointToUpdate);

	        if (!_cityInfoRepository.Save()) return InternalServerError();
			//StatusCode(500, "An error occurred while handling your request");

	        return StatusCode(HttpStatusCode.NoContent);//NoContent();
        }

  //      [HttpPatch]
  //      [Route("cities/{cityId}/pointsofinterest/{id}")]
  //      public IHttpActionResult PartiallyUpdatePointOfInterest(int cityId, int id, [FromBody] JsonPatchDocument<PointOfInterestForUpdateDto> patchDoc)
  //      {
  //          if (patchDoc == null) return BadRequest();

  //          if (!_cityInfoRepository.CityExists(cityId)) return NotFound();

		//	var pointEntity = _cityInfoRepository.GetPointOfInterestForCity(cityId, id);
		//	if (pointEntity == null) return NotFound();

	 //       var pointToPatch = Mapper.Map<PointOfInterestForUpdateDto>(pointEntity);

		//	patchDoc.ApplyTo(pointToPatch, ModelState);
		//	if (!ModelState.IsValid) return BadRequest(ModelState);

		//	if (pointToPatch.Description == pointToPatch.Name)
  //              ModelState.AddModelError("Description", "Description should not be equal to name");

  //          //TryValidateModel(pointToPatch);
  //          if (!ModelState.IsValid) return BadRequest(ModelState);

	 //       Mapper.Map(pointToPatch, pointEntity);
	 //       if (!_cityInfoRepository.Save()) return InternalServerError();
		//			//StatusCode(500, "An error occurred while handling your request");

		//	return StatusCode(HttpStatusCode.NoContent);//NoContent();
		//}

        [HttpDelete]
        [Route("cities/{cityId}/pointsofinterest/{id}")]
        public IHttpActionResult DeletePointOfAction(int cityId, int id)
        {
            if (!_cityInfoRepository.CityExists(cityId)) return NotFound();

			var pointEntity = _cityInfoRepository.GetPointOfInterestForCity(cityId, id);
			if (pointEntity == null) return NotFound();

			_cityInfoRepository.DeletePointOfInterest(pointEntity);
	        if (!_cityInfoRepository.Save()) return InternalServerError();
					//StatusCode(500, "An error occurred while handling your request");

			return StatusCode(HttpStatusCode.NoContent);//NoContent();
        }

    }
}
